from mp4reader import play

play("~/storage/downloads/party_video.mp4")
